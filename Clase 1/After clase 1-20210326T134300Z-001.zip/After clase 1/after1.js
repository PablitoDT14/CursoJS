

// VARIABLES
// Tipos de valores: string, number, true, false


// Ingreso un valor por prompt y ejecuto un saludo depende lo que ingrese

let rol = prompt('Ingrese su rol');

if (rol == 'Tutor') {
    alert('Bienvenido Tutor')
} else {
    alert('Bienvenido invitado/a')
}




// Pido tres notas, las guardo en variables, y calculo el promedio en otra variable

let notaPrimerEntrega = prompt('Ingrese nota de la primera entrega');
let notaSegundaEntrega = prompt('Ingrese nota de la segunda entrega');
let notaTercerEntrega = prompt('Ingrese nota de la tercer entrega');

// el prompt siempre devuelve un STRING

let promedioFinal = (parseInt(notaPrimerEntrega) + parseInt(notaPrimerEntrega) + parseInt(notaTercerEntrega)) / 3;

// Forma 2


/* 
//puedo hacer el prompt dentro del parseInt directamente para ahorrar pasos;

let notaPrimerEntrega = parseInt(prompt('Ingrese nota de la primera entrega'));
let notaSegundaEntrega = parseInt(prompt('Ingrese nota de la segunda entrega'))
let notaTercerEntrega = parseInt(prompt('Ingrese nota de la tercer entrega'))

let promedioFinal = (notaPrimerEntrega + notaSegundaEntrega + notaTercerEntrega) / 3;
console.log(promedioFinal)

*/


// IF condicional
// valores booleanos - TRUE o FALSE

// Si el promedio es 10, se ejecuta el primer bloque
// Si no, evalua la segunda condicion, si es mayor o igual que 7, y ejecuta el segundo bloque
// Si ninguna de las anteriores se cumple, se ejecuta el ELSE final


if (promedioFinal === 10) {
    alert('Qué grande! La nota suprema')
} else if (promedioFinal >= 7) {
    alert('Felicitaciones, estás aprobado')
    // alert('Ya podés continuar con el siguiente curso')
    // console.log('Hola joven aprobado')
} else {
    alert('Estás desaprobado')
}

console.log('Fin del ejemplo')
